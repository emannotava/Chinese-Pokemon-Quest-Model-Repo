The original model has some issues where Frogadier's right side of his face
clipped through his right nostril, fixing this was pretty easy, I just removed those faces and mirrored the other side to it.

But since this counts as modification, these modifications were saved separately.
So whatever you're going to do with this model, I highly recommend using "pq0657_fixed.obj" over the original